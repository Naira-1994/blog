<?php

class Rectangle
{
    protected $width;
    protected $height;

    public function __construct($width, $height) {
        $this->width = $width;
        $this->height = $height;
    }

    public function area() {
        return $this->width * $this->height;
    }
}
$rec = new Rectangle(5, 4);
echo $rec->area();
