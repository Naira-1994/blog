<?php

namespace Users;

use Core\Admin\Controller;

class Page extends Controller
{

}