<?php
//1./*
//•Create a trait StringTrait with 2 methods –measureLength, which
//calculates the string length, and makeUppercase, which makes all
//letters uppercase.
//•Create a class, which has a property named $message and the type is
//string.
//•Create a new instance of that class and use the trait methods for that
//object

trait StringTrait{

    function measureLength(string $str): int
    {
        return strlen($str);
    }

    function makeUppercase(string  $str): string
    {
        return strtoupper($str);
    }

}

class Lesson {
    use StringTrait;

}
$obj = new Lesson();
echo $obj->measureLength("jkifdjhgfvdhgfvd");
echo $obj->makeUppercase("jkifdjhgfvdhgfvd");
?>
<?php
//Suppose we have two classes. Simplify the code using the keyword use.
//
//namespace Core\Admin;
//class Controller
//{
//}
//
 //
//namespace Users;
//class Page extends \Core\Admin\Controller
//{
//}
//

namespace Core\Admin;
class Controller
{
}
?>

<?php
//Create a constructor and get methods using type declarations for the following class:
//<?php
//class User
//{
//    private $name;
//    private $age;
//    private $height; // in meters
//    private $isMarried;
//    private $childrenCount;
//}
class User {
    private string $name;
    private int $age;
    private int $height; // in meters
    private bool $isMarried;
    private ?int $childrenCount;

    public function __construct(string $name,int $age, int $height, bool $isMarried, ?int $childrenCount )
    {
        $this->name = $name;
        $this->age = $age;
        $this->height = $height;
        $this->isMarried = $isMarried;
        $this->childrenCount = $childrenCount;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function get_age(): int
    {
        return $this->age;
    }

    public function get_height(): int
    {
        return $this->height;
    }

    public function get_isMarried(): bool
    {
        return $this->isMarried;
    }

    public function get_childrenCount(): ?int
    {
        return $this->childrenCount;
    }
}

/*2.
Exercise
1. Using a regular expression, check if a string can be used as a
variable name in PHP.
2. Write a PHP script that checks if a string contains another string.
3. Write a PHP script that removes the whitespaces from a string
*/

function isValidVariableName($name): bool
{
    return preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $name) === 1;
}

function stringReg($string, $substring): bool
{
    $pattern = '/'. preg_quote($substring, '/') .'/';
    return preg_match($pattern, $string) === 1;
}

function removeSpacesReg($string) {
    return preg_replace('/\s+/', '', $string);
}

//Use try...catch...to handle requiring a non-existing file.

try {
    require 'non_existing_config.php';
} catch (ErrorException $e) {
    echo 'Error: ' . $e->getMessage();
}